package MyApp;

public interface Storage {


}
