package MyApp;

import DB.DepartmentDB;
import DB.DoctorDB;
import DB.NurseDB;
import DB.RoomDB;
import Hospital.Hospital;
import Personal.Staff;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.security.Key;
import java.util.ArrayList;
import java.util.HashMap;


public class GUI {
    private final JFrame jFrame;
    private Hospital hospital;

    DepartmentDB departmentDB;
    DoctorDB doctorDB;
    NurseDB nurseDB;
    RoomDB roomDB;

    public GUI() {
        this.departmentDB = new DepartmentDB();
        this.doctorDB = new DoctorDB();
        this.nurseDB = new NurseDB();
        this.roomDB = new RoomDB();

        this.jFrame = new JFrame();
        Staff receptionist = new Staff("receptionist", "Ermia", "male", "Zavari");
        this.hospital = new Hospital(receptionist);

        departmentDB.createTableIfNotExists();
        doctorDB.createTableIfNotExists();
        nurseDB.createTableIfNotExists();
        roomDB.createTableIfNotExists();
    }

    public void run() {
        jFrame.setTitle("Hospital Management");
        jFrame.setSize(400, 400);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        showMainMenu();
        jFrame.setVisible(true);
        jFrame.setLocationRelativeTo(null);
    }

    private void showMainMenu() {
        jFrame.setLayout(new BorderLayout());

        URL imageUrl = getClass().getResource("/img/starter_menu.png");
        if (imageUrl == null) {
            System.err.println("Error: Image not found!");
            return;
        }

        ImageIcon originalIcon = new ImageIcon(imageUrl);
        Image originalImage = originalIcon.getImage();

        int frameWidth = jFrame.getWidth();
        int frameHeight = jFrame.getHeight();

        Image scaledImage = originalImage.getScaledInstance(frameWidth, frameHeight, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel background = new JLabel(scaledIcon);
        background.setLayout(new BorderLayout());

        JLabel instruction = new JLabel("Press any key to continue...", SwingConstants.CENTER);
        instruction.setFont(new Font("Arial", Font.BOLD, 20));
        instruction.setForeground(Color.black);

        JPanel textPanel = new JPanel();
        textPanel.setOpaque(false);
        textPanel.add(instruction);

        background.add(textPanel, BorderLayout.SOUTH);
        jFrame.add(background);

        jFrame.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                hospitalManagerMenu();
            }
        });

        jFrame.setFocusable(true);
        jFrame.requestFocusInWindow();
        jFrame.revalidate();
        jFrame.repaint();
    }



    public void hospitalManagerMenu() {
        jFrame.getContentPane().removeAll();
        jFrame.setLayout(new GridLayout(4, 1));
        JButton addButton = new JButton("Add");
        JButton showButton = new JButton("Show");
        JButton removeButton = new JButton("Remove");
        JButton backButton = new JButton("Back");

        jFrame.add(addButton);
        jFrame.add(showButton);
        jFrame.add(removeButton);
        jFrame.add(backButton);

        addButton.addActionListener(e -> addMenu());
        showButton.addActionListener(e -> showMenu());
        removeButton.addActionListener(e -> removeMenu());
        backButton.addActionListener(e -> showMainMenu());

        jFrame.revalidate();
        jFrame.repaint();
    }

    public void addDepartment() {
        jFrame.getContentPane().removeAll();
        jFrame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        JLabel label = new JLabel("Specialty");
        JTextField specialty = new JTextField(15);
        String[] specialtyVar = new String[1];

        specialty.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateSpecialty(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateSpecialty(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateSpecialty(); }

            private void updateSpecialty() {
                specialtyVar[0] = specialty.getText();
            }
        });

        JLabel label1 = new JLabel("Department Number");
        JTextField departmentNumber = new JTextField(15);
        String[] departmentNumberVar = new String[1];

        departmentNumber.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateDepartmentNumber(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateDepartmentNumber(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateDepartmentNumber(); }

            private void updateDepartmentNumber() {
                departmentNumberVar[0] = departmentNumber.getText();
            }
        });

        JLabel label2 = new JLabel("Room");
        JTextField room = new JTextField(15);
        String[] roomVar = new String[1];

        room.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateRoom(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateRoom(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateRoom(); }

            private void updateRoom() {
                roomVar[0] = room.getText();
            }
        });

        JLabel label3 = new JLabel("Doctor");
        JTextField doctor = new JTextField(15);
        String[] doctorVar = new String[1];

        doctor.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateDoctor(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateDoctor(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateDoctor(); }

            private void updateDoctor() {
                doctorVar[0] = doctor.getText();
            }
        });

        gbc.gridy = 0;
        jFrame.add(label, gbc);
        jFrame.add(specialty, gbc);

        gbc.gridy = 1;
        jFrame.add(label1, gbc);
        jFrame.add(departmentNumber, gbc);

        gbc.gridy = 2;
        jFrame.add(label2, gbc);
        jFrame.add(room, gbc);

        gbc.gridy = 3;
        jFrame.add(label3, gbc);
        jFrame.add(doctor, gbc);

        gbc.gridy = 4;
        JButton backButton = new JButton("Back");
        jFrame.add(backButton, gbc);
        JButton submitButton = new JButton("Submit");
        jFrame.add(submitButton, gbc);

        submitButton.addActionListener(e -> {
            if (specialtyVar[0] == null || specialtyVar[0].trim().isEmpty() ||
                    departmentNumberVar[0] == null || departmentNumberVar[0].trim().isEmpty() ||
                    roomVar[0] == null || roomVar[0].trim().isEmpty() ||
                    doctorVar[0] == null || doctorVar[0].trim().isEmpty()) {
                JOptionPane.showMessageDialog(jFrame, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                System.out.println("Final Values: ");
                System.out.println("Specialty: " + specialtyVar[0]);
                System.out.println("Department Number: " + departmentNumberVar[0]);
                System.out.println("Room: " + roomVar[0]);
                System.out.println("Doctor: " + doctorVar[0]);
                departmentDB.addDepartment(specialtyVar[0], Integer.parseInt(departmentNumberVar[0]), true);
            }
        });
        backButton.addActionListener(e -> addMenu());

        jFrame.revalidate();
        jFrame.repaint();
    }


    public void addRoom() {
        jFrame.getContentPane().removeAll();
        jFrame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        JLabel label = new JLabel("Type");
        JTextField type = new JTextField(15);
        String[] typeVar = new String[1];

        type.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateType(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateType(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateType(); }

            private void updateType() {
                typeVar[0] = type.getText();
            }
        });

        JLabel label1 = new JLabel("Room Number");
        JTextField roomNumber = new JTextField(15);
        String[] roomNumberVar = new String[1];

        roomNumber.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateRoomNumber(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateRoomNumber(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateRoomNumber(); }

            private void updateRoomNumber() {
                roomNumberVar[0] = roomNumber.getText();
            }
        });

        JLabel label2 = new JLabel("Bed Count");
        JTextField bedCount = new JTextField(15);
        String[] bedCountVar = new String[1];

        bedCount.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateBedCount(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateBedCount(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateBedCount(); }

            private void updateBedCount() {
                bedCountVar[0] = bedCount.getText();
            }
        });

        JLabel label3 = new JLabel("Price");
        JTextField price = new JTextField(15);
        String[] priceVar = new String[1];

        price.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updatePrice(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updatePrice(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updatePrice(); }

            private void updatePrice() {
                priceVar[0] = price.getText();
            }
        });

        JLabel label4 = new JLabel("Feature");
        JTextField feature = new JTextField(15);
        String[] featureVar = new String[1];

        feature.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateFeature(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateFeature(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateFeature(); }

            private void updateFeature() {
                featureVar[0] = feature.getText();
            }
        });

        gbc.gridy = 0;
        jFrame.add(label, gbc);
        jFrame.add(type, gbc);

        gbc.gridy = 1;
        jFrame.add(label1, gbc);
        jFrame.add(roomNumber, gbc);

        gbc.gridy = 2;
        jFrame.add(label2, gbc);
        jFrame.add(bedCount, gbc);

        gbc.gridy = 3;
        jFrame.add(label3, gbc);
        jFrame.add(price, gbc);

        gbc.gridy = 4;
        jFrame.add(label4, gbc);
        jFrame.add(feature, gbc);

        gbc.gridy = 5;
        JButton backButton = new JButton("Back");
        jFrame.add(backButton, gbc);
        JButton submitButton = new JButton("Submit");
        jFrame.add(submitButton, gbc);

        submitButton.addActionListener(e -> {
            if (typeVar[0] == null || typeVar[0].trim().isEmpty() ||
                    roomNumberVar[0] == null || roomNumberVar[0].trim().isEmpty() ||
                    bedCountVar[0] == null || bedCountVar[0].trim().isEmpty() ||
                    priceVar[0] == null || priceVar[0].trim().isEmpty() ||
                    featureVar[0] == null || featureVar[0].trim().isEmpty()) {
                JOptionPane.showMessageDialog(jFrame, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                System.out.println("Final Values: ");
                System.out.println("Type: " + typeVar[0]);
                System.out.println("Room Number: " + roomNumberVar[0]);
                System.out.println("Bed Count: " + bedCountVar[0]);
                System.out.println("Price: " + priceVar[0]);
                System.out.println("Feature: " + featureVar[0]);
                roomDB.addRoom(typeVar[0], Integer.parseInt(roomNumberVar[0]), Integer.parseInt(bedCountVar[0]), true, Double.parseDouble(priceVar[0]));
            }
        });
        backButton.addActionListener(e -> addMenu());

        jFrame.revalidate();
        jFrame.repaint();
    }

    public void addStaff() {
        jFrame.getContentPane().removeAll();
        jFrame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        JLabel label = new JLabel("Name");
        JTextField name = new JTextField(15);
        String[] nameVar = new String[1];

        name.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateName(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateName(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateName(); }

            private void updateName() {
                nameVar[0] = name.getText();
            }
        });

        JLabel label1 = new JLabel("Last Name");
        JTextField lastName = new JTextField(15);
        String[] lastNameVar = new String[1];

        lastName.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateLastName(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateLastName(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateLastName(); }

            private void updateLastName() {
                lastNameVar[0] = lastName.getText();
            }
        });

        JLabel label2 = new JLabel("Gender");
        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        ButtonGroup genderGroup = new ButtonGroup();
        JRadioButton maleButton = new JRadioButton("Male");
        JRadioButton femaleButton = new JRadioButton("Female");
        JRadioButton otherButton = new JRadioButton("Other");

        genderGroup.add(maleButton);
        genderGroup.add(femaleButton);
        genderGroup.add(otherButton);

        genderPanel.add(maleButton);
        genderPanel.add(femaleButton);
        genderPanel.add(otherButton);

        String[] genderVar = new String[1];

        ActionListener genderListener = e -> {
            genderVar[0] = e.getActionCommand();
        };

        maleButton.addActionListener(genderListener);
        femaleButton.addActionListener(genderListener);
        otherButton.addActionListener(genderListener);

        JLabel label3 = new JLabel("Position");
        JTextField position = new JTextField(15);
        String[] positionVar = new String[1];

        position.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updatePosition(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updatePosition(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updatePosition(); }

            private void updatePosition() {
                positionVar[0] = position.getText();
            }
        });

        gbc.gridy = 0;
        jFrame.add(label, gbc);
        jFrame.add(name, gbc);

        gbc.gridy = 1;
        jFrame.add(label1, gbc);
        jFrame.add(lastName, gbc);

        gbc.gridy = 2;
        jFrame.add(label2, gbc);
        jFrame.add(genderPanel, gbc);

        gbc.gridy = 3;
        jFrame.add(label3, gbc);
        jFrame.add(position, gbc);

        gbc.gridy = 4;
        JButton backButton = new JButton("Back");
        jFrame.add(backButton, gbc);
        JButton submitButton = new JButton("Submit");
        jFrame.add(submitButton, gbc);

        submitButton.addActionListener(e -> {
            if (nameVar[0] == null || nameVar[0].trim().isEmpty() ||
                    lastNameVar[0] == null || lastNameVar[0].trim().isEmpty() ||
                    genderVar[0] == null || genderVar[0].trim().isEmpty() ||
                    positionVar[0] == null || positionVar[0].trim().isEmpty()) {
                JOptionPane.showMessageDialog(jFrame, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                System.out.println("Final Values: ");
                System.out.println("Name: " + nameVar[0]);
                System.out.println("Last Name: " + lastNameVar[0]);
                System.out.println("Gender: " + genderVar[0]);
                System.out.println("Position: " + positionVar[0]);
            }
        });
        backButton.addActionListener(e -> addMenu());

        jFrame.revalidate();
        jFrame.repaint();
    }

    public void addPatient() {
        jFrame.getContentPane().removeAll();
        jFrame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        JLabel label = new JLabel("Name");
        JTextField name = new JTextField(15);
        String[] nameVar = new String[1];

        name.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateName(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateName(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateName(); }

            private void updateName() {
                nameVar[0] = name.getText();
            }
        });

        JLabel label1 = new JLabel("Last Name");
        JTextField lastName = new JTextField(15);
        String[] lastNameVar = new String[1];

        lastName.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateLastName(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateLastName(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateLastName(); }

            private void updateLastName() {
                lastNameVar[0] = lastName.getText();
            }
        });

        JLabel label2 = new JLabel("Gender");
        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        ButtonGroup genderGroup = new ButtonGroup();
        JRadioButton maleButton = new JRadioButton("Male");
        JRadioButton femaleButton = new JRadioButton("Female");
        JRadioButton otherButton = new JRadioButton("Other");

        genderGroup.add(maleButton);
        genderGroup.add(femaleButton);
        genderGroup.add(otherButton);

        genderPanel.add(maleButton);
        genderPanel.add(femaleButton);
        genderPanel.add(otherButton);

        String[] genderVar = new String[1];
        ActionListener genderListener = e -> genderVar[0] = e.getActionCommand();
        maleButton.addActionListener(genderListener);
        femaleButton.addActionListener(genderListener);
        otherButton.addActionListener(genderListener);

        JLabel label3 = new JLabel("Age");
        JTextField age = new JTextField(15);
        String[] ageVar = new String[1];

        age.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateAge(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateAge(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateAge(); }

            private void updateAge() {
                ageVar[0] = age.getText();
            }
        });

        JLabel label4 = new JLabel("National Code");
        JTextField nationalCode = new JTextField(15);
        String[] nationalCodeVar = new String[1];

        nationalCode.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateNationalCode(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateNationalCode(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateNationalCode(); }

            private void updateNationalCode() {
                nationalCodeVar[0] = nationalCode.getText();
            }
        });

        JLabel label5 = new JLabel("Illness");
        JTextField illness = new JTextField(15);
        String[] illnessVar = new String[1];

        illness.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateIllness(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateIllness(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateIllness(); }

            private void updateIllness() {
                illnessVar[0] = illness.getText();
            }
        });

        JLabel label6 = new JLabel("Insurance");
        String[] insuranceOptions = {"None", "Basic", "Premium", "VIP"};
        JComboBox<String> insurance = new JComboBox<>(insuranceOptions);
        String[] insuranceVar = new String[1];
        insurance.addActionListener(e -> insuranceVar[0] = (String) insurance.getSelectedItem());

        JLabel label7 = new JLabel("Pregnancy");
        JPanel pregnantPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        ButtonGroup pregnantGroup = new ButtonGroup();
        JRadioButton yesPregnant = new JRadioButton("Yes");
        JRadioButton noPregnant = new JRadioButton("No");
        pregnantGroup.add(yesPregnant);
        pregnantGroup.add(noPregnant);
        pregnantPanel.add(yesPregnant);
        pregnantPanel.add(noPregnant);
        String[] pregnantVar = new String[1];
        ActionListener pregnantListener = e -> pregnantVar[0] = e.getActionCommand();
        yesPregnant.addActionListener(pregnantListener);
        noPregnant.addActionListener(pregnantListener);

        gbc.gridy = 0; jFrame.add(label, gbc); jFrame.add(name, gbc);
        gbc.gridy = 1; jFrame.add(label1, gbc); jFrame.add(lastName, gbc);
        gbc.gridy = 2; jFrame.add(label2, gbc); jFrame.add(genderPanel, gbc);
        gbc.gridy = 3; jFrame.add(label3, gbc); jFrame.add(age, gbc);
        gbc.gridy = 4; jFrame.add(label4, gbc); jFrame.add(nationalCode, gbc);
        gbc.gridy = 5; jFrame.add(label5, gbc); jFrame.add(illness, gbc);
        gbc.gridy = 6; jFrame.add(label6, gbc); jFrame.add(insurance, gbc);
        gbc.gridy = 7; jFrame.add(label7, gbc); jFrame.add(pregnantPanel, gbc);

        gbc.gridy = 8;
        JButton backButton = new JButton("Back");
        jFrame.add(backButton, gbc);
        JButton submitButton = new JButton("Submit");
        jFrame.add(submitButton, gbc);

        submitButton.addActionListener(e -> {
            if (nameVar[0] == null || nameVar[0].trim().isEmpty() ||
                    lastNameVar[0] == null || lastNameVar[0].trim().isEmpty() ||
                    genderVar[0] == null || genderVar[0].trim().isEmpty() ||
                    ageVar[0] == null || nationalCodeVar[0].trim().isEmpty() ||
                    illnessVar[0] == null ||  pregnantVar[0] == null) {
                JOptionPane.showMessageDialog(jFrame, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
            }
            else{
                System.out.println("Final Values: ");
                System.out.println("Name: " + nameVar[0]);
                System.out.println("Last Name: " + lastNameVar[0]);
                System.out.println("Gender: " + genderVar[0]);
                System.out.println("Age: " + ageVar[0]);
                System.out.println("National Code: " + nationalCodeVar[0]);
                System.out.println("Illness: " + illnessVar[0]);
                System.out.println("Insurance: " + insuranceVar[0]);
                System.out.println("Pregnant: " + pregnantVar[0]);
            }
        });
        backButton.addActionListener(e -> addMenu());

        jFrame.revalidate();
        jFrame.repaint();
    }


    public void addNurse() {
        jFrame.getContentPane().removeAll();
        jFrame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        JLabel label = new JLabel("Name");
        JTextField name = new JTextField(15);
        String[] nameVar = new String[1];

        name.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateName(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateName(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateName(); }

            private void updateName() {
                nameVar[0] = name.getText();
            }
        });

        JLabel label1 = new JLabel("Last Name");
        JTextField lastName = new JTextField(15);
        String[] lastNameVar = new String[1];

        lastName.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateLastName(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateLastName(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateLastName(); }

            private void updateLastName() {
                lastNameVar[0] = lastName.getText();
            }
        });

        JLabel label2 = new JLabel("Gender");
        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        ButtonGroup genderGroup = new ButtonGroup();
        JRadioButton maleButton = new JRadioButton("Male");
        JRadioButton femaleButton = new JRadioButton("Female");
        JRadioButton otherButton = new JRadioButton("Other");

        genderGroup.add(maleButton);
        genderGroup.add(femaleButton);
        genderGroup.add(otherButton);

        genderPanel.add(maleButton);
        genderPanel.add(femaleButton);
        genderPanel.add(otherButton);

        String[] genderVar = new String[1];
        ActionListener genderListener = e -> genderVar[0] = e.getActionCommand();
        maleButton.addActionListener(genderListener);
        femaleButton.addActionListener(genderListener);
        otherButton.addActionListener(genderListener);

        JLabel label3 = new JLabel("National Code");
        JTextField nationalCode = new JTextField(15);
        String[] nationalCodeVar = new String[1];

        nationalCode.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateNationalCode(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateNationalCode(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateNationalCode(); }

            private void updateNationalCode() {
                nationalCodeVar[0] = nationalCode.getText();
            }
        });

        gbc.gridy = 0; jFrame.add(label, gbc); jFrame.add(name, gbc);
        gbc.gridy = 1; jFrame.add(label1, gbc); jFrame.add(lastName, gbc);
        gbc.gridy = 2; jFrame.add(label2, gbc); jFrame.add(genderPanel, gbc);
        gbc.gridy = 3; jFrame.add(label3, gbc); jFrame.add(nationalCode, gbc);

        gbc.gridy = 4;
        JButton backButton = new JButton("Back");
        jFrame.add(backButton, gbc);
        JButton submitButton = new JButton("Submit");
        jFrame.add(submitButton, gbc);

        submitButton.addActionListener(e -> {
            System.out.println("Final Values: ");
            System.out.println("Name: " + nameVar[0]);
            System.out.println("Last Name: " + lastNameVar[0]);
            System.out.println("Gender: " + genderVar[0]);
            System.out.println("National Code: " + nationalCodeVar[0]);
            nurseDB.addNurse(nameVar[0], lastNameVar[0], genderVar[0], Integer.parseInt(nationalCodeVar[0]));
        });
        backButton.addActionListener(e -> addMenu());

        jFrame.revalidate();
        jFrame.repaint();
    }

    public void addDoctor() {
        jFrame.getContentPane().removeAll();
        jFrame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        JLabel label = new JLabel("Name");
        JTextField name = new JTextField(15);
        String[] nameVar = new String[1];

        name.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateName(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateName(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateName(); }

            private void updateName() {
                nameVar[0] = name.getText();
            }
        });

        JLabel label1 = new JLabel("Last Name");
        JTextField lastName = new JTextField(15);
        String[] lastNameVar = new String[1];

        lastName.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateLastName(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateLastName(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateLastName(); }

            private void updateLastName() {
                lastNameVar[0] = lastName.getText();
            }
        });

        JLabel label2 = new JLabel("Gender");
        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        ButtonGroup genderGroup = new ButtonGroup();
        JRadioButton maleButton = new JRadioButton("Male");
        JRadioButton femaleButton = new JRadioButton("Female");
        JRadioButton otherButton = new JRadioButton("Other");

        genderGroup.add(maleButton);
        genderGroup.add(femaleButton);
        genderGroup.add(otherButton);

        genderPanel.add(maleButton);
        genderPanel.add(femaleButton);
        genderPanel.add(otherButton);

        String[] genderVar = new String[1];

        ActionListener genderListener = e -> {
            genderVar[0] = e.getActionCommand();
        };

        maleButton.addActionListener(genderListener);
        femaleButton.addActionListener(genderListener);
        otherButton.addActionListener(genderListener);

        JLabel label3 = new JLabel("Medical Code");
        JTextField medicalCode = new JTextField(15);
        String[] medicalCodeVar = new String[1];

        medicalCode.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateMedicalCode(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateMedicalCode(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateMedicalCode(); }

            private void updateMedicalCode() {
                medicalCodeVar[0] = medicalCode.getText();
            }
        });

        JLabel label4 = new JLabel("Specialty");
        JTextField specialty = new JTextField(15);
        String[] specialtyVar = new String[1];

        specialty.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateSpecialty(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateSpecialty(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateSpecialty(); }

            private void updateSpecialty() {
                specialtyVar[0] = specialty.getText();
            }
        });

        gbc.gridy = 0;
        jFrame.add(label, gbc);
        jFrame.add(name, gbc);

        gbc.gridy = 1;
        jFrame.add(label1, gbc);
        jFrame.add(lastName, gbc);

        gbc.gridy = 2;
        jFrame.add(label2, gbc);
        jFrame.add(genderPanel, gbc);

        gbc.gridy = 3;
        jFrame.add(label3, gbc);
        jFrame.add(medicalCode, gbc);

        gbc.gridy = 4;
        jFrame.add(label4, gbc);
        jFrame.add(specialty, gbc);

        gbc.gridy = 5;
        JButton backButton = new JButton("Back");
        jFrame.add(backButton, gbc);
        JButton submitButton = new JButton("Submit");
        jFrame.add(submitButton, gbc);

        submitButton.addActionListener(e -> {
            if (nameVar[0] == null || nameVar[0].trim().isEmpty() ||
                    lastNameVar[0] == null || lastNameVar[0].trim().isEmpty() ||
                    genderVar[0] == null || genderVar[0].trim().isEmpty() ||
                    medicalCodeVar[0] == null || medicalCodeVar[0].trim().isEmpty() ||
                    specialtyVar[0] == null || specialtyVar[0].trim().isEmpty()) {
                JOptionPane.showMessageDialog(jFrame, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                System.out.println("Final Values: ");
                System.out.println("Name: " + nameVar[0]);
                System.out.println("Last Name: " + lastNameVar[0]);
                System.out.println("Gender: " + genderVar[0]);
                System.out.println("Medical Code: " + medicalCodeVar[0]);
                System.out.println("Specialty: " + specialtyVar[0]);
                doctorDB.addDoctor(nameVar[0], lastNameVar[0], genderVar[0], Integer.parseInt(medicalCodeVar[0]), specialtyVar[0]);
            }
        });
        backButton.addActionListener(e -> addMenu());

        jFrame.revalidate();
        jFrame.repaint();
    }

    // Add options
    public void addMenu() {
        jFrame.getContentPane().removeAll();
        jFrame.setLayout(new GridLayout(7, 1));
        JButton departmentButton = new JButton("Department");
        JButton roomButton = new JButton("Room");
        JButton staffButton = new JButton("Staff");
        JButton patientButton = new JButton("Patient");
        JButton nurseButton = new JButton("Nurse");
        JButton doctorButton = new JButton("Doctor");
        JButton backButton = new JButton("Back");

        jFrame.add(departmentButton);
        jFrame.add(roomButton);
        jFrame.add(staffButton);
        jFrame.add(patientButton);
        jFrame.add(nurseButton);
        jFrame.add(doctorButton);
        jFrame.add(backButton);

        backButton.addActionListener(e -> hospitalManagerMenu());

      departmentButton.addActionListener(e -> addDepartment());
      roomButton.addActionListener(e ->  addRoom());
       staffButton.addActionListener(e ->  addStaff());
       patientButton.addActionListener(e -> addPatient());
       nurseButton.addActionListener(e -> addNurse());
     doctorButton.addActionListener(e -> addDoctor());

        jFrame.revalidate();
        jFrame.repaint();
    }
    private void showDepartment() {
        jFrame.getContentPane().removeAll();
        jFrame.setLayout(new BorderLayout());

        ArrayList<HashMap<String, Object>> departments = departmentDB.showAll();

        String[] columnNames = {"ID", "Speciality", "Department Number", "Availability"};

        Object[][] data = new Object[departments.size()][4];
        for (int i = 0; i < departments.size(); i++) {
            HashMap<String, Object> department = departments.get(i);
            data[i][0] = department.get("id");
            data[i][1] = department.get("name");
            data[i][2] = department.get("departmentNumber").toString(); // Ensure String format
            data[i][3] = department.get("isAvailable").toString(); // Ensure String format
        }

        JTable table = new JTable(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0; // Make ID column non-editable
            }
        };
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Ensure at least 5 rows are visible before scrolling
        table.setPreferredScrollableViewportSize(new Dimension(600, table.getRowHeight() * 5));
        table.setFillsViewportHeight(true);

        JScrollPane scrollPane = new JScrollPane(table);
        jFrame.getContentPane().add(scrollPane, BorderLayout.CENTER);

        // Back Button
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> showMenu());
        jFrame.getContentPane().add(backButton, BorderLayout.SOUTH);

        // Edit Button
        JButton editButton = new JButton("Edit Selected");
        editButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                int id = Integer.parseInt(table.getValueAt(selectedRow, 0).toString());
                String name = table.getValueAt(selectedRow, 1).toString();
                int departmentNumber = Integer.parseInt(table.getValueAt(selectedRow, 2).toString());
                boolean isAvailable = Boolean.parseBoolean(table.getValueAt(selectedRow, 3).toString());

                editDepartment(id, name, departmentNumber, isAvailable);
            }
        });
        jFrame.getContentPane().add(editButton, BorderLayout.NORTH);

        jFrame.pack();
        jFrame.setSize(800, 600);
        jFrame.setVisible(true);
        jFrame.revalidate();
        jFrame.repaint();
    }
    private void editDepartment(int departmentId, String name, int departmentNumber, boolean isAvailable) {
        JTextField nameField = new JTextField(name);
        JTextField departmentNumberField = new JTextField(String.valueOf(departmentNumber));
        JCheckBox availabilityCheckBox = new JCheckBox("Available", isAvailable);

        Object[] fields = {
                "Speciality:", nameField,
                "Department Number:", departmentNumberField,
                "Availability:", availabilityCheckBox
        };

        int option = JOptionPane.showConfirmDialog(jFrame, fields, "Edit Department", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String updatedName = nameField.getText();
            int updatedDepartmentNumber = Integer.parseInt(departmentNumberField.getText());
            boolean updatedAvailability = availabilityCheckBox.isSelected();

            departmentDB.updateDepartment(departmentId, updatedName, updatedAvailability, updatedDepartmentNumber);
            showDepartment();
        }
    }



    private void showRoom() {
        jFrame.getContentPane().removeAll();
        jFrame.setLayout(new BorderLayout());

        // Fetch room data from the database
        ArrayList<HashMap<String, Object>> rooms = roomDB.showAll();

        String[] columnNames = {"ID", "Type", "Room Number", "Bed Count", "Availability", "Price"};
        Object[][] data = new Object[rooms.size()][6];

        for (int i = 0; i < rooms.size(); i++) {
            HashMap<String, Object> room = rooms.get(i);
            data[i][0] = room.get("id");
            data[i][1] = room.get("type");
            data[i][2] = room.get("roomNumber").toString();
            data[i][3] = room.get("bedCount").toString();
            data[i][4] = room.get("isAvailable").toString();
            data[i][5] = room.get("price").toString();
        }

        JTable table = new JTable(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0; // ID column should not be editable
            }
        };
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setPreferredScrollableViewportSize(new Dimension(700, table.getRowHeight() * 6));
        table.setFillsViewportHeight(true);

        JScrollPane scrollPane = new JScrollPane(table);
        jFrame.getContentPane().add(scrollPane, BorderLayout.CENTER);

        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> showMenu());
        jFrame.getContentPane().add(backButton, BorderLayout.SOUTH);

        JButton editButton = new JButton("Edit Selected");
        editButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                int id = Integer.parseInt(table.getValueAt(selectedRow, 0).toString());
                String type = table.getValueAt(selectedRow, 1).toString();
                int roomNumber = Integer.parseInt(table.getValueAt(selectedRow, 2).toString());
                int bedCount = Integer.parseInt(table.getValueAt(selectedRow, 3).toString());
                boolean isAvailable = Boolean.parseBoolean(table.getValueAt(selectedRow, 4).toString());
                double price = Double.parseDouble(table.getValueAt(selectedRow, 5).toString());

                editRoom(id, type, roomNumber, bedCount, isAvailable, price);
            }
        });
        jFrame.getContentPane().add(editButton, BorderLayout.NORTH);

        jFrame.pack();
        jFrame.setSize(900, 600);
        jFrame.setVisible(true);
        jFrame.revalidate();
        jFrame.repaint();
    }

    private void editRoom(int id, String type, int roomNumber, int bedCount, boolean isAvailable, double price) {
        JTextField typeField = new JTextField(type);
        JTextField roomNumberField = new JTextField(String.valueOf(roomNumber));
        JTextField bedCountField = new JTextField(String.valueOf(bedCount));
        JCheckBox availabilityCheckBox = new JCheckBox("Available", isAvailable);
        JTextField priceField = new JTextField(String.valueOf(price));

        Object[] fields = {
                "Type:", typeField,
                "Room Number:", roomNumberField,
                "Bed Count:", bedCountField,
                "Availability:", availabilityCheckBox,
                "Price:", priceField
        };

        int option = JOptionPane.showConfirmDialog(jFrame, fields, "Edit Room", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String updatedType = typeField.getText();
            int updatedRoomNumber = Integer.parseInt(roomNumberField.getText());
            int updatedBedCount = Integer.parseInt(bedCountField.getText());
            boolean updatedAvailability = availabilityCheckBox.isSelected();
            double updatedPrice = Double.parseDouble(priceField.getText());

            roomDB.updateRoom(id, updatedType, updatedAvailability, updatedRoomNumber, updatedBedCount, updatedPrice);
            showRoom();
        }
    }

    private void showDoctor() {
        jFrame.getContentPane().removeAll();
        jFrame.setLayout(new BorderLayout());

        // Fetch doctor data from the database
        ArrayList<HashMap<String, Object>> doctors = doctorDB.showAll();

        String[] columnNames = {"ID", "Name", "Last Name", "Gender", "Medical Code", "Speciality"};
        Object[][] data = new Object[doctors.size()][6];

        for (int i = 0; i < doctors.size(); i++) {
            HashMap<String, Object> doctor = doctors.get(i);
            data[i][0] = doctor.get("id");
            data[i][1] = doctor.get("name");
            data[i][2] = doctor.get("lastName");
            data[i][3] = doctor.get("gender");
            data[i][4] = doctor.get("medicalCode").toString();
            data[i][5] = doctor.get("speciality");
        }

        JTable table = new JTable(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0;
            }
        };
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setPreferredScrollableViewportSize(new Dimension(700, table.getRowHeight() * 6));
        table.setFillsViewportHeight(true);

        JScrollPane scrollPane = new JScrollPane(table);
        jFrame.getContentPane().add(scrollPane, BorderLayout.CENTER);

        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> showMenu());
        jFrame.getContentPane().add(backButton, BorderLayout.SOUTH);

        JButton editButton = new JButton("Edit Selected");
        editButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                int id = Integer.parseInt(table.getValueAt(selectedRow, 0).toString());
                String name = table.getValueAt(selectedRow, 1).toString();
                String lastName = table.getValueAt(selectedRow, 2).toString();
                String gender = table.getValueAt(selectedRow, 3).toString();
                int medicalCode = Integer.parseInt(table.getValueAt(selectedRow, 4).toString());
                String speciality = table.getValueAt(selectedRow, 5).toString();

                editDoctor(id, name, lastName, gender, medicalCode, speciality);
            }
        });
        jFrame.getContentPane().add(editButton, BorderLayout.NORTH);

        jFrame.pack();
        jFrame.setSize(900, 600);
        jFrame.setVisible(true);
        jFrame.revalidate();
        jFrame.repaint();
    }

    private void editDoctor(int id, String name, String lastName, String gender, int medicalCode, String speciality) {
        JTextField nameField = new JTextField(name);
        JTextField lastNameField = new JTextField(lastName);
        JTextField genderField = new JTextField(gender);
        JTextField medicalCodeField = new JTextField(String.valueOf(medicalCode));
        JTextField specialityField = new JTextField(speciality);

        Object[] fields = {
                "Name:", nameField,
                "Last Name:", lastNameField,
                "Gender:", genderField,
                "Medical Code:", medicalCodeField,
                "Speciality:", specialityField
        };

        int option = JOptionPane.showConfirmDialog(jFrame, fields, "Edit Doctor", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String updatedName = nameField.getText();
            String updatedLastName = lastNameField.getText();
            String updatedGender = genderField.getText();
            int updatedMedicalCode = Integer.parseInt(medicalCodeField.getText());
            String updatedSpeciality = specialityField.getText();

            doctorDB.updateDoctor(id, updatedName, updatedLastName, updatedGender, updatedMedicalCode, updatedSpeciality);
            showDoctor();
        }
    }

    private void showNurse() {
        jFrame.getContentPane().removeAll();
        jFrame.setLayout(new BorderLayout());

        ArrayList<HashMap<String, Object>> nurses = nurseDB.showAll();

        String[] columnNames = {"ID", "Name", "Last Name", "Gender", "National Code"};
        Object[][] data = new Object[nurses.size()][5];

        for (int i = 0; i < nurses.size(); i++) {
            HashMap<String, Object> nurse = nurses.get(i);
            data[i][0] = nurse.get("id");
            data[i][1] = nurse.get("name");
            data[i][2] = nurse.get("lastName");
            data[i][3] = nurse.get("gender");
            data[i][4] = nurse.get("nationalCode").toString();
        }

        JTable table = new JTable(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0; // ID column should not be editable
            }
        };
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setPreferredScrollableViewportSize(new Dimension(700, table.getRowHeight() * 6));
        table.setFillsViewportHeight(true);

        JScrollPane scrollPane = new JScrollPane(table);
        jFrame.getContentPane().add(scrollPane, BorderLayout.CENTER);

        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> showMenu());
        jFrame.getContentPane().add(backButton, BorderLayout.SOUTH);

        JButton editButton = new JButton("Edit Selected");
        editButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                int id = Integer.parseInt(table.getValueAt(selectedRow, 0).toString());
                String name = table.getValueAt(selectedRow, 1).toString();
                String lastName = table.getValueAt(selectedRow, 2).toString();
                String gender = table.getValueAt(selectedRow, 3).toString();
                int nationalCode = Integer.parseInt(table.getValueAt(selectedRow, 4).toString());

                editNurse(id, name, lastName, gender, nationalCode);
            }
        });
        jFrame.getContentPane().add(editButton, BorderLayout.NORTH);

        jFrame.pack();
        jFrame.setSize(900, 600);
        jFrame.setVisible(true);
        jFrame.revalidate();
        jFrame.repaint();
    }

    private void editNurse(int id, String name, String lastName, String gender, int nationalCode) {
        JTextField nameField = new JTextField(name);
        JTextField lastNameField = new JTextField(lastName);
        JTextField genderField = new JTextField(gender);
        JTextField nationalCodeField = new JTextField(String.valueOf(nationalCode));

        Object[] fields = {
                "Name:", nameField,
                "Last Name:", lastNameField,
                "Gender:", genderField,
                "National Code:", nationalCodeField
        };

        int option = JOptionPane.showConfirmDialog(jFrame, fields, "Edit Nurse", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String updatedName = nameField.getText();
            String updatedLastName = lastNameField.getText();
            String updatedGender = genderField.getText();
            int updatedNationalCode = Integer.parseInt(nationalCodeField.getText());

            nurseDB.updateNurse(id, updatedName, updatedLastName, updatedGender, updatedNationalCode);
            showNurse();
        }
    }


    public void showMenu() {
        jFrame.setSize(400, 400);
        jFrame.getContentPane().removeAll();
        jFrame.setLayout(new GridLayout(9, 1));
        JButton departmentButton = new JButton("Show Departments");
        JButton roomButton = new JButton("Show Rooms");
        JButton staffButton = new JButton("Show Staffs");
        JButton patientButton = new JButton("Show Patients");
        JButton nurseButton = new JButton("Show Nurses");
        JButton doctorButton = new JButton("Show Doctors");
        JButton reserveButton = new JButton("Show Reserves");
        JButton paymentButton = new JButton("Show Payments");
        JButton backButton = new JButton("Back");


        jFrame.add(departmentButton);
        jFrame.add(roomButton);
        jFrame.add(staffButton);
        jFrame.add(patientButton);
        jFrame.add(nurseButton);
        jFrame.add(doctorButton);
        jFrame.add(reserveButton);
        jFrame.add(paymentButton);
        jFrame.add(backButton);

        departmentButton.addActionListener(e -> showDepartment());
        roomButton.addActionListener(e -> showRoom());


        nurseButton.addActionListener(e -> showNurse());
        doctorButton.addActionListener(e -> showDoctor());
        backButton.addActionListener(e -> hospitalManagerMenu());

        jFrame.revalidate();
        jFrame.repaint();
    }
    //Remove options
    public void removeMenu() {
        jFrame.getContentPane().removeAll();
        jFrame.setLayout(new GridLayout(7, 1));
        JButton departmentButton = new JButton("Department");
        JButton roomButton = new JButton("Room");
        JButton staffButton = new JButton("Staff");
        JButton patientButton = new JButton("Patient");
        JButton nurseButton = new JButton("Nurse");
        JButton doctorButton = new JButton("Doctor");
        JButton backButton = new JButton("Back");

        jFrame.add(departmentButton);
        jFrame.add(roomButton);
        jFrame.add(staffButton);
        jFrame.add(patientButton);
        jFrame.add(nurseButton);
        jFrame.add(doctorButton);
        jFrame.add(backButton);

        backButton.addActionListener(e -> hospitalManagerMenu());

        jFrame.repaint();
    }
}
