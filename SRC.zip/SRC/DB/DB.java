package DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public abstract class DB {
    protected String url;
    protected String user ;
    protected String password;

    public DB() {
        this.url = "jdbc:postgresql://localhost:5432/Hospital";
        this.user = "postgres";
        this.password = "admin1234";
    }
    public Connection connect() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }
}
