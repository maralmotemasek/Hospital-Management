package DB;

public class PatientDB {
}
